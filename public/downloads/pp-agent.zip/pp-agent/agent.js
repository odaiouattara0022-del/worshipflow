/**
 * pp-agent — ProPresenter Local Bridge Agent
 *
 * Polls the WorshipFlow server for commands and executes them locally
 * against ProPresenter's HTTP API and the local filesystem.
 *
 * Usage: node agent.js  (or run pp-agent.exe after packaging)
 */

"use strict";

const fs = require("fs");
const path = require("path");
const { dispatch } = require("./handlers");

// ---------------------------------------------------------------------------
// Config — loaded from pp-agent-config.json (written by setup.js)
// ---------------------------------------------------------------------------
const CONFIG_FILE = path.join(__dirname, "pp-agent-config.json");

function loadConfig() {
  if (!fs.existsSync(CONFIG_FILE)) {
    console.error(
      "\n❌  Configuration introuvable.\n" +
        "   Lancez d'abord: node setup.js\n"
    );
    process.exit(1);
  }
  return JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8"));
}

// ---------------------------------------------------------------------------
// Main polling loop
// ---------------------------------------------------------------------------
const POLL_INTERVAL_MS = 500;
const MAX_BACKOFF_MS = 30_000;
const HEARTBEAT_LOG_INTERVAL = 60; // print "agent running" every N polls

let consecutiveErrors = 0;
let pollCount = 0;

async function poll(config) {
  const { serverUrl, agentToken } = config;
  const url = `${serverUrl}/api/pp-bridge/poll`;

  let data;
  try {
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${agentToken}` },
      signal: AbortSignal.timeout(10_000),
    });

    if (res.status === 401) {
      console.error("❌  Token invalide — relancez node setup.js pour vous réenregistrer.");
      process.exit(1);
    }

    if (!res.ok) {
      throw new Error(`Serveur a retourné ${res.status}`);
    }

    data = await res.json();
    consecutiveErrors = 0;
  } catch (err) {
    consecutiveErrors++;
    const backoff = Math.min(POLL_INTERVAL_MS * consecutiveErrors, MAX_BACKOFF_MS);
    if (consecutiveErrors <= 3 || consecutiveErrors % 10 === 0) {
      console.warn(`⚠️  Erreur réseau (${consecutiveErrors}): ${err.message}. Retry dans ${backoff}ms`);
    }
    await sleep(backoff);
    return;
  }

  pollCount++;
  if (pollCount % HEARTBEAT_LOG_INTERVAL === 0) {
    console.log(`✓  Agent actif — ${new Date().toLocaleTimeString()}`);
  }

  if (!data.command) return;

  const cmd = data.command;
  console.log(`→  Commande reçue: ${cmd.command} (id: ${cmd.id.slice(0, 8)}...)`);

  // Acknowledge immediately
  await ackCommand(config, cmd.id);

  let result = null;
  let error = null;
  try {
    const params = JSON.parse(cmd.params || "{}");
    result = await dispatch(cmd.command, params, config);
    console.log(`✓  Commande ${cmd.command} exécutée avec succès`);
  } catch (err) {
    error = err instanceof Error ? err.message : String(err);
    console.error(`✗  Erreur commande ${cmd.command}: ${error}`);
  }

  await postResult(config, cmd.id, result, error);
}

async function ackCommand(config, commandId) {
  const { serverUrl, agentToken } = config;
  try {
    await fetch(`${serverUrl}/api/pp-bridge/ack`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${agentToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ commandId }),
      signal: AbortSignal.timeout(5_000),
    });
  } catch {
    // Non-fatal — server will timeout eventually
  }
}

async function postResult(config, commandId, result, error) {
  const { serverUrl, agentToken } = config;
  try {
    await fetch(`${serverUrl}/api/pp-bridge/result`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${agentToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ commandId, result, error: error ?? undefined }),
      signal: AbortSignal.timeout(10_000),
    });
  } catch (err) {
    console.error(`⚠️  Impossible d'envoyer le résultat: ${err.message}`);
  }
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------
async function main() {
  const config = loadConfig();

  console.log("╔══════════════════════════════════════════════════╗");
  console.log("║        PP Agent — WorshipFlow Bridge v1.0        ║");
  console.log("╚══════════════════════════════════════════════════╝");
  console.log(`  Serveur : ${config.serverUrl}`);
  console.log(`  Appareil: ${config.deviceName || config.deviceId}`);
  console.log(`  PP API  : http://${config.ppHost}:${config.ppPort}`);
  console.log("─────────────────────────────────────────────────────");
  console.log("  En attente de commandes... (Ctrl+C pour quitter)");
  console.log("");

  // Main loop
  // eslint-disable-next-line no-constant-condition
  while (true) {
    await poll(config);
    await sleep(POLL_INTERVAL_MS);
  }
}

main().catch((err) => {
  console.error("Erreur fatale:", err);
  process.exit(1);
});
