/**
 * setup.js — Wizard de configuration de pp-agent.
 *
 * Demande uniquement ce qui est strictement nécessaire :
 *   1. URL de WorshipFlow
 *   2. ID de l'appareil ProPresenter
 *
 * ProPresenter tourne sur le même ordinateur → hôte/port auto-détectés.
 * Dossier PP auto-détecté depuis le profil Windows courant.
 */

"use strict";

const fs = require("fs");
const path = require("path");
const readline = require("readline");
const os = require("os");

const CONFIG_FILE = path.join(__dirname, "pp-agent-config.json");

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

function ask(label, defaultValue) {
  return new Promise((resolve) => {
    const hint = defaultValue ? ` [${defaultValue}]` : "";
    process.stdout.write(`  ${label}${hint} : `);
    rl.once("line", (line) => {
      const val = line.trim();
      resolve(val || defaultValue || "");
    });
  });
}

function detectPPDataPath() {
  const username = os.userInfo().username;
  const candidates = [
    path.join("C:", "Users", username, "Documents", "ProPresenter"),
    path.join(os.homedir(), "Documents", "ProPresenter"),
  ];
  for (const c of candidates) {
    if (fs.existsSync(c)) return c;
  }
  return candidates[0];
}

function detectProtoDir() {
  const username = os.userInfo().username;
  // Common locations where PP7 proto files may exist
  const candidates = [
    // Developer / existing extraction
    path.join("C:", "Users", username, "AppData", "Local", "Temp", "pp7proto", "Proto 19beta"),
    path.join(os.homedir(), "AppData", "Local", "Temp", "pp7proto", "Proto 19beta"),
    // Inside ProPresenter app bundle (various versions)
    "C:\\Program Files\\ProPresenter\\proto",
    "C:\\Program Files (x86)\\ProPresenter\\proto",
  ];
  for (const c of candidates) {
    if (fs.existsSync(c) && fs.existsSync(path.join(c, "presentation.proto"))) return c;
  }
  return null;
}

async function testPPConnection(host, port) {
  try {
    const res = await fetch(`http://${host}:${port}/version`, {
      signal: AbortSignal.timeout(2000),
    });
    if (res.ok) {
      const d = await res.json();
      return d.versionString || d.version || "OK";
    }
  } catch { /* ignore */ }
  return null;
}

async function main() {
  console.log("");
  console.log("  ================================================");
  console.log("    Configuration de l'agent ProPresenter");
  console.log("  ================================================");
  console.log("");
  console.log("  Vous avez besoin de 2 informations :");
  console.log("   • L'URL de votre WorshipFlow");
  console.log("   • L'ID de l'appareil (dans WorshipFlow → Paramètres → Appareils)");
  console.log("");

  // ── URL du serveur ──────────────────────────────────────────
  const serverUrl = (await ask("URL WorshipFlow", "https://prosendworship.vercel.app")).replace(/\/$/, "");

  if (!serverUrl.startsWith("http")) {
    console.error("\n  ERREUR : URL invalide (doit commencer par https://)");
    process.exit(1);
  }

  // ── ID de l'appareil ────────────────────────────────────────
  const deviceId = await ask("ID de l'appareil");

  if (!deviceId) {
    console.error("\n  ERREUR : L'ID de l'appareil est requis.");
    console.error("  Trouvez-le dans WorshipFlow → Paramètres → Appareils ProPresenter.");
    process.exit(1);
  }

  // ── Détection automatique de ProPresenter ───────────────────
  console.log("");
  console.log("  Détection automatique de ProPresenter...");

  const ppHost = "127.0.0.1";
  const ppPort = 1025;
  const ppVersion = await testPPConnection(ppHost, ppPort);

  if (ppVersion) {
    console.log(`  ✓ ProPresenter détecté (v${ppVersion})`);
  } else {
    console.log("  ⚠ ProPresenter non accessible sur le port 1025.");
    console.log("    Assurez-vous que ProPresenter est ouvert et que l'API HTTP est activée :");
    console.log("    ProPresenter → Préférences → Réseau → Activer l'API HTTP (port 1025)");
    console.log("    L'agent continuera quand même — ProPresenter peut être lancé plus tard.");
  }

  // ── Dossier de données PP ────────────────────────────────────
  const ppDataPath = detectPPDataPath();
  if (fs.existsSync(ppDataPath)) {
    console.log(`  ✓ Dossier ProPresenter détecté : ${ppDataPath}`);
  } else {
    console.log(`  ⚠ Dossier ProPresenter non trouvé (sera créé si besoin)`);
  }

  // ── Dossier proto ────────────────────────────────────────────
  const protoDir = detectProtoDir();
  if (protoDir) {
    console.log(`  ✓ Fichiers proto ProPresenter détectés : ${protoDir}`);
  } else {
    console.log(`  ⚠ Fichiers proto non trouvés — génération de fichiers .pro désactivée.`);
    console.log(`    (L'agent fonctionnera pour le contrôle, statut, etc.)`);
  }

  // ── Enregistrement auprès du serveur ────────────────────────
  console.log("");
  console.log("  Connexion à WorshipFlow...");

  let agentToken;
  try {
    const res = await fetch(`${serverUrl}/api/pp-bridge/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ deviceId, setupKey: deviceId }),
      signal: AbortSignal.timeout(20_000),
    });

    if (res.status === 401) {
      console.error("");
      console.error("  ERREUR : ID d'appareil invalide ou non autorisé.");
      console.error("  Vérifiez l'ID dans WorshipFlow → Paramètres → Appareils ProPresenter.");
      console.error("  L'ID ressemble à : xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx");
      process.exit(1);
    }
    if (res.status === 404) {
      console.error("");
      console.error("  ERREUR : Cet appareil n'existe pas dans WorshipFlow.");
      console.error("  Créez-le dans WorshipFlow → Paramètres → Appareils ProPresenter,");
      console.error("  puis relancez install.bat.");
      process.exit(1);
    }
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      console.error(`\n  ERREUR serveur (${res.status}) : ${text}`);
      process.exit(1);
    }

    const data = await res.json();
    agentToken = data.agentToken;
    console.log("  ✓ Agent enregistré avec succès");
  } catch (err) {
    if (err.name === "TimeoutError" || err.code === "UND_ERR_CONNECT_TIMEOUT") {
      console.error("\n  ERREUR : Le serveur ne répond pas.");
    } else {
      console.error(`\n  ERREUR réseau : ${err.message}`);
    }
    console.error("  Vérifiez l'URL et votre connexion Internet, puis relancez.");
    process.exit(1);
  }

  // ── Sauvegarde de la configuration ──────────────────────────
  const config = {
    serverUrl,
    deviceId,
    agentToken,
    ppHost,
    ppPort,
    ppDataPath,
    protoDir: protoDir || null,
  };

  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), "utf8");

  console.log("  ✓ Configuration sauvegardée");
  console.log("");

  rl.close();
}

main().catch((err) => {
  console.error("\n  Erreur inattendue :", err.message);
  process.exit(1);
});
